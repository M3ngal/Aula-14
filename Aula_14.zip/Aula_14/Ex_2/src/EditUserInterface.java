import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class EditUserInterface extends JFrame {
    private JTextField senhaField;
    private JTextField p1Field;
    private JTextField p2Field;
    private JTextField trabalhoField;
    private JTextField faltasField;
    private User user;
    private Connection conn;

    public EditUserInterface(Connection conn, User user) {
        super("Editar Usuário");
        this.conn = conn;
        this.user = user;

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        // Campo de senha
        JLabel senhaLabel = new JLabel("Senha:");
        gbc.gridy = 0;
        add(senhaLabel, gbc);

        senhaField = new JTextField(user.getSenha(), 18);
        gbc.gridy = 1;
        add(senhaField, gbc);

        // Campo de P1
        JLabel p1Label = new JLabel("P1:");
        gbc.gridy = 2;
        add(p1Label, gbc);

        p1Field = new JTextField(String.valueOf(user.getP1()), 18);
        gbc.gridy = 3;
        add(p1Field, gbc);

        // Campo de P2
        JLabel p2Label = new JLabel("P2:");
        gbc.gridy = 4;
        add(p2Label, gbc);

        p2Field = new JTextField(String.valueOf(user.getP2()), 18);
        gbc.gridy = 5;
        add(p2Field, gbc);

        // Campo de trabalho
        JLabel trabalhoLabel = new JLabel("Trabalho:");
        gbc.gridy = 6;
        add(trabalhoLabel, gbc);

        trabalhoField = new JTextField(String.valueOf(user.getTrabalho()), 18);
        gbc.gridy = 7;
        add(trabalhoField, gbc);

        // Campo de faltas
        JLabel faltasLabel = new JLabel("Faltas:");
        gbc.gridy = 8;
        add(faltasLabel, gbc);

        faltasField = new JTextField(String.valueOf(user.getFaltas()), 18);
        gbc.gridy = 9;
        add(faltasField, gbc);

        // Botão de salvar
        JButton saveButton = new JButton("Salvar");
        gbc.gridy = 10;
        add(saveButton, gbc);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleSave();
            }
        });

        setSize(300, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void handleSave() {
        user.setSenha(senhaField.getText());
        user.setP1(Double.parseDouble(p1Field.getText()));
        user.setP2(Double.parseDouble(p2Field.getText()));
        user.setTrabalho(Double.parseDouble(trabalhoField.getText()));
        user.setFaltas(Integer.parseInt(faltasField.getText()));

        user.atualizar(conn);
        JOptionPane.showMessageDialog(this, "Informações atualizadas com sucesso!");
    }
}
