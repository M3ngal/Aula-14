package Ex_1.Ex_1a;

import javax.swing.JFrame;

public class ComboBoxTest {
    public static void main(String args[]) {
        ComboBoxFrame comboBoxFrame = new ComboBoxFrame();
        comboBoxFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        comboBoxFrame.setSize(350, 150);
        comboBoxFrame.setVisible(true);
    }
}
