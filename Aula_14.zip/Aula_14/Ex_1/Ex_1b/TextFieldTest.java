package Ex_1.Ex_1b;

import javax.swing.JFrame;

public class TextFieldTest { 
    public static void main(String args[]) {
        TextFieldFrame textFieldFrame = new TextFieldFrame();
        textFieldFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE); 
        textFieldFrame.setSize( 325, 125 );  
        textFieldFrame.setVisible(true); 
    }
}