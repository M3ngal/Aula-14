package Ex_1.Ex_1c;

public class PhoneBookTest {
    public static void main(String args[]) {
        PhoneBook pb1 = new PhoneBook();
        pb1.makeWindow();
    }
}
